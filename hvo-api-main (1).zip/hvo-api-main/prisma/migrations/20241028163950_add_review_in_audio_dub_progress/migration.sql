-- AlterEnum
ALTER TYPE "AudioDubProgress" ADD VALUE 'REVIEW';
