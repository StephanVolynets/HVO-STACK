-- AlterTable
ALTER TABLE "AudioDub" ADD COLUMN     "root_folder_id" TEXT;
