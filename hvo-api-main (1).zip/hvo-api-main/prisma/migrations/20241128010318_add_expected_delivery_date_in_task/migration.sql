-- AlterTable
ALTER TABLE "Task" ADD COLUMN     "expected_delivery_date" TIMESTAMP(3);
