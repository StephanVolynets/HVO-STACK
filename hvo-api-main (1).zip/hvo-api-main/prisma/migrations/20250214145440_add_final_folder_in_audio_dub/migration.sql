-- AlterTable
ALTER TABLE "AudioDub" ADD COLUMN     "final_folder_id" TEXT;
