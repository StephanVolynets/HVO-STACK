-- AlterTable
ALTER TABLE "Video" ADD COLUMN     "isPrepeared" BOOLEAN DEFAULT false;
