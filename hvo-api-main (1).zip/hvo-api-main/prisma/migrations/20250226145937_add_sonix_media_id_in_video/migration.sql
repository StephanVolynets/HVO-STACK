-- AlterTable
ALTER TABLE "Video" ADD COLUMN     "sonixMediaId" TEXT;
