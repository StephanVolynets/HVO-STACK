-- AlterTable
ALTER TABLE "Video" ADD COLUMN     "rawTranscriptReady" BOOLEAN DEFAULT false;
