-- AlterTable
ALTER TABLE "Video" ADD COLUMN     "deliverables_folder_id" TEXT,
ADD COLUMN     "raw_script_folder_id" TEXT,
ADD COLUMN     "source_files_folder_id" TEXT;
