-- AlterTable
ALTER TABLE "Video" ADD COLUMN     "expected_by" TIMESTAMP(3);
