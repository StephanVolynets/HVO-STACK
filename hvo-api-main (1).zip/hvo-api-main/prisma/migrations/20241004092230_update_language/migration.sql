-- AlterTable
ALTER TABLE "Language" ADD COLUMN     "flag_url" TEXT;
