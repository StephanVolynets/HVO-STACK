-- AlterTable
ALTER TABLE "Language" ADD COLUMN     "countryName" TEXT;
