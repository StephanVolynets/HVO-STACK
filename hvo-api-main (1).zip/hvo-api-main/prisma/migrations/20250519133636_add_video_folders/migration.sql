-- AlterTable
ALTER TABLE "Video" ADD COLUMN     "m_and_e_folder_id" TEXT,
ADD COLUMN     "mp4_folder_id" TEXT,
ADD COLUMN     "raw_audio_folder_id" TEXT;
