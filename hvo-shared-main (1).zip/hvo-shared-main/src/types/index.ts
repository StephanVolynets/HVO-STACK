export type TIME_PERIOD = "ALL" | "TODAY" | "WEEK" | "MONTH" | "YEAR";
