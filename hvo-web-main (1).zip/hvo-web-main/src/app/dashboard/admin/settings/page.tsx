import { SettingsView } from "@/sections/shared/settings";

export default function SettignsPage() {
  return <SettingsView />;
}
