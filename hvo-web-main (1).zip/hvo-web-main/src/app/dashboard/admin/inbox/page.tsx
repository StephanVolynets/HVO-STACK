import { InboxView } from "@/sections/admin/inbox";

export default function InboxPage() {
  return <InboxView />;
}
