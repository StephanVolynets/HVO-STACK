import { CreatorsView } from "@/sections/admin/creators";

export const metadata = {
  title: "HVO Admin",
};

export default function CreatorsPage() {
  return <CreatorsView />;
}
