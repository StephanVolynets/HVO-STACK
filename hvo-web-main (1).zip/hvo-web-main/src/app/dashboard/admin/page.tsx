export const metadata = {
  title: "Human Voice Over",
};

export default function LoginPage() {
  return <>Admin Overview</>;
}
