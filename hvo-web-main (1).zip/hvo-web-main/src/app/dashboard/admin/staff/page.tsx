import StaffView from "@/sections/admin/staff/staff-view";

export default function StaffPage() {
  return <StaffView />;
}
