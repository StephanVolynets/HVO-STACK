export const metadata = {
  title: "HVO Staff",
};

export default function LoginPage() {
  return <>Staff Page Here</>;
}
