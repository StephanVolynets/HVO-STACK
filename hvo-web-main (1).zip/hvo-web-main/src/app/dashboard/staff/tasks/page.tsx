import { TasksView } from "@/sections/staff/tasks";

export const metadata = {
  title: "Tasks",
};

export default function TasksPage() {
  return <TasksView />;
}
