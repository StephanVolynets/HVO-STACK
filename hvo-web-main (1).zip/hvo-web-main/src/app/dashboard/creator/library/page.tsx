import { LibraryView } from "@/sections/creator/library";

export const metadata = {
  title: "My Library",
};

export default function LibraryPage() {
  return <LibraryView />;
}
