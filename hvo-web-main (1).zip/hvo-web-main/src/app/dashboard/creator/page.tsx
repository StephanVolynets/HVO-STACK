export const metadata = {
  title: "HVO Creator",
};

export default function LoginPage() {
  return <>Creator Page Here</>;
}
