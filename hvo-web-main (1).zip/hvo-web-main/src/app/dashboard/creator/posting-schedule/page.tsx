import { PostingScheduleView } from "@/sections/creator/posting-schedule";

export default function PostingSchedulePage() {
  return <PostingScheduleView />;
}
