import { YoutubeTrackerView } from "@/sections/creator/youtube-tracker";

export default function YoutubeTrackerPage() {
  return <YoutubeTrackerView />;
}
