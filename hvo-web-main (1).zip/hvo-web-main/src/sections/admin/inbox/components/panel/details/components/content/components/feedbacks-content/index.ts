export { default as FeedbacksContent } from "./feedbacks-content";
