export { default as Content } from "./content";
