export { default as Details } from "./details";
