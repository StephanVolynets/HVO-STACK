import { Stack } from "@mui/material";

export default function HandleChanges() {
  return (
    <Stack spacing={1.5}>
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        {/* test */}
      </Stack>
    </Stack>
  );
}
