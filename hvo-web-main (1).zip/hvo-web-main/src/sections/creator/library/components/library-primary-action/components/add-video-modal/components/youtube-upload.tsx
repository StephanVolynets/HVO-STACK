import { Typography } from "@mui/material";

type Props = {
  open: boolean;
  onSuccessfulSubmit: () => void;
};

export default function YoutubeUpload({ open, onSuccessfulSubmit }: Props) {
  return <Typography>Youtube Uplaod</Typography>;
}
