import { AddVideoDTO, CreateCreatorDTO } from "hvo-shared";

export const formDefaultValues: AddVideoDTO = {
  title: "",
  description: "",
  // youtube_url: "",
  video_file_id: "",
  soundtrack_file_id: "",
  // session_folder_id: "",
  session_id: "",
};
