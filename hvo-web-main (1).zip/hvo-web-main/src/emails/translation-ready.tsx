import { Text } from "@react-email/components";
import { EmailWrapper } from "./shared/email-wrapper";

interface Props {
  title?: string;
  creatorName?: string;
  videoLink?: string;
  scriptLanguage?: string;
  scriptLink?: string;
  dueDate?: string;
  uploadLink?: string;
}

const TranslationReadyEmail: React.FC<Props> = ({
  title,
  creatorName,
  videoLink,
  scriptLanguage,
  scriptLink,
  dueDate,
  uploadLink,
}) => {
  return (
    <EmailWrapper>
      <Text style={{ fontSize: "16px", color: "#333" }}>Hi,</Text>
      <Text style={{ fontSize: "16px", marginBottom: "10px" }}>
        A new <strong>{creatorName}</strong> video arrived.
      </Text>
      <Text style={{ fontSize: "16px", marginBottom: "10px" }}>
        <strong>Title:</strong> {title}
      </Text>
      <Text style={{ fontSize: "16px", marginBottom: "10px" }}>
        Here is the video:{" "}
        <a href={videoLink} style={{ color: "#0F4C81", textDecoration: "underline" }}>
          {videoLink}
        </a>
      </Text>
      <Text style={{ fontSize: "16px", marginBottom: "10px" }}>
        Here is the <strong>{scriptLanguage}</strong> script:{" "}
        <a href={scriptLink} style={{ color: "#0F4C81", textDecoration: "underline" }}>
          {scriptLink}
        </a>
      </Text>
      <Text style={{ fontSize: "16px", marginBottom: "10px" }}>
        We would need the final <strong>{scriptLanguage}</strong> audios by <strong>{dueDate}</strong>.
      </Text>
      <Text style={{ fontSize: "16px", marginBottom: "20px" }}>
        When completed, please upload here:{" "}
        <a href={uploadLink} style={{ color: "#0F4C81", textDecoration: "underline" }}>
          {uploadLink}
        </a>
      </Text>
    </EmailWrapper>
  );
};

export default TranslationReadyEmail;
