export { default as PhasesCollapsed } from "./phases-collapsed";
