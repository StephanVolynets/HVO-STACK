export { default as Modal } from "./modal";
